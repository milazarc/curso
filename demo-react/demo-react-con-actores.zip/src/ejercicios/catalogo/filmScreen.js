import React, { Component } from 'react'

export default class FilmScreen extends Component {
  render() {
    return (
      <div>FilmScreen</div>
    )
  }
}
